/**
 * JINBASE E-Certificate — Backend Search API
 * ============================================================
 * Tujuan utama file ini: memindahkan seluruh data kontributor
 * (nama + email) dan logika pencarian ke server, sehingga
 * browser pengguna TIDAK PERNAH menerima daftar lengkap
 * kontributor — hanya hasil pencarian yang relevan untuk
 * query yang mereka kirim.
 *
 * Cara jalankan:
 *   cd server
 *   npm install
 *   npm start
 *   -> API tersedia di http://localhost:3000/api/search
 * ============================================================
 */

const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

/* ------------------------------------------------------------
   LOAD DATA (sekali saat startup, hanya ada di memori server)
------------------------------------------------------------ */
const DATA_PATH = path.join(__dirname, 'data', 'contributors.json');

let contributors = [];

function loadContributors() {
  try {
    const raw = fs.readFileSync(DATA_PATH, 'utf-8');
    const parsed = JSON.parse(raw);
    contributors = Array.isArray(parsed.contributors) ? parsed.contributors : [];
    console.log(`✅ Loaded ${contributors.length} contributors (server-side only).`);
  } catch (err) {
    console.error('❌ Failed to load contributors.json:', err.message);
    contributors = [];
  }
}
loadContributors();

/* ------------------------------------------------------------
   MIDDLEWARE
------------------------------------------------------------ */
app.use(express.json());

// Batasi origin yang boleh memanggil API ini di production.
// Ganti '*' dengan domain frontend kamu, mis. 'https://btsjinproject.com'
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));

// Rate limit: cegah brute-force menebak-nebak email satu per satu.
const searchLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 menit
  max: 20,             // maksimal 20 request pencarian per menit per IP
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Terlalu banyak percobaan. Coba lagi sebentar lagi.' },
});

/* ------------------------------------------------------------
   HELPERS — dipindahkan apa adanya dari app.js lama
------------------------------------------------------------ */
function normalize(str) {
  return (str || '').toLowerCase().trim().replace(/\s+/g, ' ');
}

function stripKey(str) {
  return normalize(str).replace(/[^a-z0-9]/g, '');
}

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) =>
    Array.from({ length: n + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}

function maskEmail(email) {
  if (!email) return '';
  const [local, domain] = email.split('@');
  if (!domain) return email;
  return `${local[0]}***@${domain}`;
}

/**
 * Sama persis dengan logika lama di app.js, hanya sekarang
 * jalan di server dan hasilnya sudah di-mask sebelum dikirim.
 */
function searchContributors(query) {
  const q = normalize(query);
  const qKey = stripKey(query);
  if (!q || q.length < 2) return [];

  const exact = [];
  const substring = [];
  const fuzzy = [];

  for (const c of contributors) {
    const emailNorm = normalize(c.email || '');
    const emailKey = stripKey(c.email || '');
    if (!emailNorm) continue;

    if (emailNorm === q || emailKey === qKey) {
      exact.push({ contributor: c, score: 0 });
      continue;
    }

    if (
      emailNorm.includes(q) || emailKey.includes(qKey) ||
      q.includes(emailNorm) || qKey.includes(emailKey)
    ) {
      substring.push({ contributor: c, score: 1 });
      continue;
    }

    if (qKey.length >= 4 && emailKey.length >= 4) {
      const dist = levenshtein(qKey, emailKey);
      const maxDist = emailKey.length <= 10 ? 2 : 3;
      if (dist <= maxDist) {
        fuzzy.push({ contributor: c, score: 2 + dist });
      }
    }
  }

  return [...exact, ...substring, ...fuzzy]
    .sort((a, b) => a.score - b.score)
    .map(r => r.contributor);
}

/* ------------------------------------------------------------
   ROUTES
------------------------------------------------------------ */

// Health check — untuk memastikan server & data hidup
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', contributorsLoaded: contributors.length });
});

/**
 * POST /api/search
 * body: { email: string }
 *
 * Mengembalikan HANYA hasil yang cocok (maks 10), dengan email
 * di-mask. Tidak pernah mengirim seluruh database ke client.
 */
app.post('/api/search', searchLimiter, (req, res) => {
  const { email } = req.body || {};

  if (typeof email !== 'string' || email.trim().length < 3) {
    return res.status(400).json({ error: 'Masukkan minimal 3 karakter email.' });
  }

  const matches = searchContributors(email).slice(0, 10);

  const results = matches.map((c, i) => ({
    id: i,                              // hanya untuk keperluan disambiguasi di UI
    name: c.name,
    maskedEmail: maskEmail(c.email),
    contribution_type: c.contribution_type || 'money',
  }));

  return res.json({ results });
});

/* ------------------------------------------------------------
   START
------------------------------------------------------------ */
app.listen(PORT, () => {
  console.log(`🚀 JINBASE search API running at http://localhost:${PORT}`);
});
